#ifndef LDPC_H
#define LDPC_H

#include <iostream>
#include "gf2mat.h"
#include "smat.h"

class LDPC_Parity
{
    public:
    //! Default constructor
    LDPC_Parity() : init_flag(false) {}

    //! Constructor that gives an empty matrix of size ncheck x nvar
    LDPC_Parity(int ncheck, int nvar);

    //! Load an LDPC code from a alist file
    LDPC_Parity(const std::string& filename);

    //! Constructor, from a \c GF2mat_sparse_alist object
    LDPC_Parity(const GF2mat_sparse_alist& alist);

    //! Display some information about the matrix
    virtual void display_stats() const;

    //! Initialize an empty matrix of size ncheck x nvar
    void initialize(int ncheck, int nvar);

    //! Get the code rate
    double get_rate() const {
        return (1.0 - static_cast<double>(ncheck) / nvar);
    }

    //! Import matrix from \c GF2mat_sparse_alist format
    void import_alist(const GF2mat_sparse_alist& H_alist);

    //! Get the parity check matrix, optionally its transformed form
    sparse_bin_matrix get_H(bool transpose = false) const {
        return (transpose ? Ht : H);
    } // FIXME Ht not implemented

    protected:

    //! Flag that indicates proper initialization
    bool init_flag;

    //! Number of variable nodes
    int nvar;

    //! Number of check nodes
    int ncheck;

    //! The parity check matrix
    sparse_bin_matrix H;

    //! The transpose of the parity check matrix
    sparse_bin_matrix Ht;   // FIXME Ht not implemented
};

#endif
