#include <iostream>
#include "smat.h"
#include "svec.h"

std::vector<int> sparse_bin_matrix::get_column(int column) {
    return columns[column].get_vect();
}

void sparse_bin_matrix::set_element(int column,
        int row, int value) {
    columns[column].set_element(row, value);
}

sparse_bin_matrix::sparse_bin_matrix(int m, int n) {
    M = m;
    N = n;
    columns.resize(N);
    for (int i = 0; i < N; i++)
        columns[i].resize(M);
}

void sparse_bin_matrix::display_info () {
    std::cout << "M " << M << std::endl;
    std::cout << "N " << N << std::endl;
    std::cout << "columns.size() " << columns.size() << std::endl;
    std::cout << "columns[0].size() " << columns[0].size();
    std::cout << std::endl;
    std::cout << "columns[N-1].size() " << columns[N-1].size();
    std::cout << std::endl;
}
