from gf2mat import *
import time
import copy
import numpy as np

class LDPC_Parity:

    def __init__(self, ncheck = 0, nvar = 0, alist = None):
        if ( alist != None ):
            self.load_alist(alist)
        else:
            self.ncheck = int(ncheck)
            self.nvar = int(nvar)

    def load_alist(self, alist):
        self.alist = alist
        self.nvar = alist.nvar
        self.nchk = alist.ncheck
        self.matob = GF2mat(alist = self.alist)
        self.col_weight = self.alist.num_nlist
        self.row_weight = self.alist.num_mlist

class ldpc_encoder:

    def __init__(self, LDPC_Parity = None):
        if LDPC_Parity != None:
            self.matob = LDPC_Parity.matob

    def encode(self, dataword):
        return self.matob.back_substitution(dataword)
        

class bp_decoder:

    def __init__(self, LDPC_Parity = None, epsilon = 0):
        if LDPC_Parity != None:
            self.nvar = LDPC_Parity.nvar
            self.nchk = LDPC_Parity.nchk
            self.nlist = LDPC_Parity.alist.nlist
            self.mlist = LDPC_Parity.alist.mlist
            self.H = LDPC_Parity.matob.H
            self.epsilon = epsilon
            self.max_iterations = 50

    def map_word(self, word):
        mapped_word = numpy.zeros(word.shape, dtype = int)
        for i in range(len(word)):
            if word[i] == 1:
                mapped_word[i] = -1
            else:
                mapped_word[i] = 1
        return mapped_word
    
    def remap_word(self, word):
        remap_wd = numpy.zeros(word.shape, dtype = int)
        for i in range(len(word)):
            if word[i] == 1:
                remap_wd[i] = 0
            else:
                remap_wd[i] = 1
        return remap_wd

    def setup_Gallager_A(self, word):
        self.msg_var2chk = numpy.zeros((self.nchk, self.nvar),
                dtype = int)
        self.msg_chk2var = numpy.zeros((self.nchk, self.nvar),
                dtype = int)
        self.msg_temp = numpy.zeros((self.nchk, self.nvar),
                dtype = int)
        for col in range(self.nvar):
            for row in self.nlist[col]:
                self.msg_var2chk[row - 1, col] = word[col]

    def Gallager_A(self, codeword):
        self.mapped_word = self.map_word(codeword)
        self.temp_wd = copy.copy(self.mapped_word)
        self.set_indices()
        self.setup_Gallager_A(self.mapped_word)

    def Gallager_A_decode(self):
        self.compute_chk2var_msg()
        self.current_chk2var = copy.copy(self.msg_chk2var)
        self.current_var2chk = copy.copy(self.msg_var2chk)
        iteration = 1
        while iteration < self.max_iterations:
            self.compute_var2chk_msg()
            self.compute_chk2var_msg()
            iteration += 1
            if self.message_stability():
                return (True, self.try_decode()[0],
                        self.try_decode()[1])
        if iteration == self.max_iterations:
            return (False, False,
                    self.remap_word(self.mapped_word))


    def try_decode(self):
        success = True
        codeword = np.zeros((self.nvar, 1), dtype = int)
        for var in range(self.nvar):
            temp = self.msg_chk2var[self.nlist[var][0] - 1, var]
            for chk in self.nlist[var]:
                if self.msg_chk2var[chk - 1, var] != temp:
                    success = False
                    return success, codeword
            if success:
                codeword[var] = temp
        return success, self.remap_word(codeword)

    def message_stability(self):
        condition1 = np.array_equal(self.current_chk2var,
                self.msg_chk2var)
        condition2 = np.array_equal(self.current_var2chk,
                self.msg_var2chk)
        if condition1 and condition2:
            return True
        else:
            self.current_chk2var = copy.copy(self.msg_chk2var)
            self.current_var2chk = copy.copy(self.msg_var2chk)
            return False
            
    def setup_bp_decoder(self, epsilon):
        self.Q_0 = numpy.zeros((self.nchk, self.nvar),
                dtype = float)
        self.Q_1 = numpy.zeros((self.nchk, self.nvar),
                dtype = float)
        self.DQ = numpy.zeros((self.nchk, self.nvar),
                dtype = float)
        self.R_0 = numpy.zeros((self.nchk, self.nvar),
                dtype = float)
        self.R_1 = numpy.zeros((self.nchk, self.nvar),
                dtype = float)
        self.DR = numpy.zeros((self.nchk, self.nvar),
                dtype = float)
        self.temp_err_word = numpy.zeros((self.nvar, 1),
                dtype = int)

        for row in range(self.nchk):
            for col in self.mlist[row]:
                self.Q_0[row, col-1] = 1 - epsilon
                self.Q_1[row, col-1] = epsilon

        self.DQ = self.Q_0 - self.Q_1
        self.set_indices()

    def set_indices(self):
        self.row_index_set = []
        for row in range(self.nchk):
            self.row_index_set.append([])
            for j in range(len(self.mlist[row])):
                self.row_index_set[row].append([])
                col = self.mlist[row][j]
                index_set = copy.copy(self.mlist[row])
                index_set.remove(col)
                for k in range(len(index_set)):
                    self.row_index_set[row][j].append(index_set[k] - 1)

        self.col_index_set = []
        for col in range(self.nvar):
            self.col_index_set.append([])
            for j in range(len(self.nlist[col])):
                self.col_index_set[col].append([])
                row = self.nlist[col][j]
                index_set = copy.copy(self.nlist[col])
                index_set.remove(row)
                for k in range(len(index_set)):
                    self.col_index_set[col][j].append(index_set[k] - 1)

    def compute_syndrome(self, codeword):
        syndrome = numpy.dot(self.H, codeword)
        for i in range(len(syndrome)):
            syndrome[i] = syndrome[i]%2
        self.syndrome = syndrome

    def check_syndrome(self):
        syndrome = numpy.dot(self.H, self.temp_err_word)
        print syndrome

    def bp(self, codeword):
        self.setup_decoder(self.epsilon)
        self.compute_syndrome(codeword)
        for i in range(10):
            self.horizontal_step()
            self.vertical_step()
            self.temp_word()
            self.check_syndrome()

    def horizontal_step(self):
        for row in range(self.nchk):
            for i in range(len(self.mlist[row])):
                product = pow(-1, self.syndrome[row])
                col = self.mlist[row][i] - 1
                for j in self.row_index_set[row][i]:
                    product = product*self.DQ[row][j]
                self.DR[row, col] = product
                self.R_0[row, col] = (1 + product)/2.0
                self.R_1[row, col] = (1 - product)/2.0

    def vertical_step(self):
        for col in range(self.nvar):
            for i in range(len(self.nlist[col])):
                product_0 = 1 - self.epsilon
                product_1 = self.epsilon
                row = self.nlist[col][i] - 1
                for j in self.col_index_set[col][i]:
                    product_0 = product_0 * self.R_0[row, col]
                    product_1 = product_1 * self.R_1[row, col]
                product_sum = product_0 + product_1
                self.Q_0[row, col] = product_0/product_sum
                self.Q_1[row, col] = product_1/product_sum

    def compute_chk2var_msg(self):
        for chk in range(self.nchk):
            for i in range(len(self.mlist[chk])):
                product = 1
                var = self.mlist[chk][i] - 1
                for j in self.row_index_set[chk][i]:
                    product = product * self.msg_var2chk[chk, j]
                self.msg_chk2var[chk, var] = product

    def compute_var2chk_msg(self):
        word = self.temp_wd
        for var in range(self.nvar):
            for i in range(len(self.nlist[var])):
                m0 = word[var]
                chk = self.nlist[var][i] - 1
                match = True
                temp = self.msg_chk2var[self.col_index_set[var][i][0], var]
                for j in self.col_index_set[var][i]:
                    if self.msg_chk2var[j, var] != temp:
                        match = False
                        break
                if match:
                    self.msg_var2chk[chk, var] = temp
                else:
                    self.msg_var2chk[chk, var] = m0

    def temp_word(self):
        for col in range(self.nvar):
            product_0 = 1 - self.epsilon
            product_1 = self.epsilon
            for  row in self.nlist[col]:
                product_0 = product_0 * self.R_0[row - 1, col]
                product_1 = product_1 * self.R_1[row - 1, col]
            if product_0 > product_1:
                self.temp_err_word[col, 0] = 0
            else:
                self.temp_err_word[col, 0] = 1
