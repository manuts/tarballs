from numpy import *
from copy import copy
class variable_node:
    def __init__(self):
        self.checks = []

class check_node:
    def __init__(self):
        self.variables = []

class tanner_graph:
    def __init__(self, H):
        self.variable_nodes = []
        self.check_nodes = []

        for j in range(shape(H)[1]):
            node = variable_node()
            for i in range(shape(H)[0]):
                if H[i,j] == 1:
                    node.checks.append(i)
            self.variable_nodes.append(node)
            
        for i in range(shape(H)[0]):
            node = check_node()
            for j in range(shape(H)[1]):
                if H[i,j] == 1:
                    node.variables.append(j)
            self.check_nodes.append(node)

class message_passing_decoder:
    def __init__(self, H, epsilon, syndrome, tanner):
        self.H = H
        self.epsilon = epsilon
        self.syndrome = syndrome
        self.tanner = tanner
        self.n_check_node = shape(H)[0]
        self.n_variable_node = shape(H)[1]
        self.temp_syndrome = syndrome
        self.estimate = zeros((self.n_variable_node, 1))
        self.Q_Zero = zeros((self.n_variable_node, 1))
        self.Q_One = zeros((self.n_variable_node, 1))
        self.Q_Zero_Matrix = zeros(shape(H))
        self.Q_One_Matrix = zeros(shape(H))
        self.R_Zero_Matrix = zeros(shape(H))
        self.R_One_Matrix = zeros(shape(H))
        self.delta_R = zeros(shape(H))
        self.delta_Q = zeros(shape(H))

        for i in range(self.n_check_node):
            for j in range(self.n_variable_node):
                if H[i, j] == 1:
                    self.Q_Zero_Matrix[i, j] = 1 - epsilon
                    self.Q_One_Matrix[i, j] = epsilon

    def horizontal_step(self):
        self.delta_Q = self.Q_Zero_Matrix - self.Q_One_Matrix
        for i in range(self.n_check_node):
            for j in range(self.n_variable_node):
                if self.H[i, j] == 1:
                    varlist = copy(self.tanner.check_nodes[i].variables)
                    print varlist
                    varlist.remove(j)
                    print varlist
                    self.delta_R[i, j] = pow(-1, self.syndrome[i, 0])
                    for k in varlist:
                        self.delta_R[i, j] = self.delta_R[i, j]*self.delta_Q[i, k]
                    self.R_Zero_Matrix[i, j] = (1.0 + self.delta_R[i, j])/2.0
                    self.R_One_Matrix[i, j] = (1.0 - self.delta_R[i, j])/2.0

    def vertical_step(self):
        for i in range(self.n_check_node):
            for j in range(self.n_variable_node):
                if self.H[i, j] == 1:
                    checklist = copy(self.tanner.variable_nodes[j].checks)
                    checklist.remove(i)
                    self.Q_Zero_Matrix[i, j] = 1 - self.epsilon
                    self.Q_One_Matrix[i, j] = self.epsilon
                    for k in checklist:
                        self.Q_Zero_Matrix[i, j] = self.Q_Zero_Matrix[i, j]*self.R_Zero_Matrix[k, j]
                        self.Q_One_Matrix[i, j] = self.Q_One_Matrix[i, j]*self.R_One_Matrix[k, j]
                    normal_factor = self.Q_Zero_Matrix[i, j] + self.Q_One_Matrix[i, j]
                    self.Q_Zero_Matrix[i, j] = self.Q_Zero_Matrix[i, j]/normal_factor
                    self.Q_One_Matrix[i, j] = self.Q_One_Matrix[i, j]/normal_factor

    def compute_ppp(self):
        for i in range(self.n_variable_node):
            checklist = self.tanner.variable_nodes[i].checks
            self.Q_Zero[i, 0] = 1 - self.epsilon
            self.Q_One[i, 0] = self.epsilon
            for k in checklist:
                self.Q_Zero[i, 0] = self.Q_Zero[i, 0]*self.R_Zero_Matrix[k, i]
                self.Q_One[i] = self.Q_One[i, 0]*self.R_One_Matrix[k, i]
            normal_factor = self.Q_Zero[i, 0] + self.Q_One[i, 0]
            self.Q_Zero[i, 0] = self.Q_Zero[i, 0]/normal_factor
            self.Q_One[i, 0] = self.Q_One[i, 0]/normal_factor

    def decode(self):
        self.compute_ppp()
        for i in range(self.n_check_node):
            if (self.Q_One[i, 0] > 0.5):
                self.estimate[i, 0] = 1
            else:
                self.estimate[i, 0] = 0
        self.temp_syndrome = dot(self.H, self.estimate)
#        for i in range(self.n_check_node):
#            if temp_syndrome[i, 0] % 2:
#                temp_syndrome[i, 0] = 1
#            else:
#                temp_syndrome[i, 0] = 0
#        if temp_syndrome == self.syndrome:
#            return True
#        else:
#            return False
