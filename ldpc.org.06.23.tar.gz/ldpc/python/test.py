from GallagerA import *
from numpy import *
#from ldpc import generate_H
from hamming import generate_H

# H = mat("1 0 0 1 0 1 1; 0 1 0 1 1 1 0; 0 0 1 0 1 1 1")
H = generate_H(1)
n_check_node = shape(H)[0]
n_variable_node = shape(H)[1]
tanner = tanner_graph(H)
codeword = random.randint(0, 1, (n_variable_node, 1))
epsilon = 0.1
channel = random.uniform(0.0, 1.0, (n_variable_node, 1))
n_errors = 0
for i in range(n_variable_node):
    if channel[i, 0] < epsilon:
        codeword[i, 0] = 1
        n_errors += 1
#codeword[6, 0] = 1
#codeword[19, 0] = 1
print codeword, n_errors
syndrome = dot(H, codeword)
for i in range(n_check_node):
    if syndrome[i, 0] % 2:
        syndrome[i, 0] = 1
    else:
        syndrome[i, 0] = 0
print "sybdrome"
print syndrome
tanner = tanner_graph(H)
decoder = message_passing_decoder(H, epsilon, syndrome, tanner)
print "Q_Zero_Matrix"
print decoder.Q_Zero_Matrix
print "horizontal step"
decoder.horizontal_step()
print "delta_Q"
print decoder.delta_Q
print "delta_R"
print decoder.delta_R
print "R_Zero_Matrix"
print decoder.R_Zero_Matrix
print "R_One_Matrix"
print decoder.R_One_Matrix
print "vertical step"
decoder.vertical_step()
print "Q_Zero_Matrix"
print decoder.Q_Zero_Matrix
print "Q_One_Matrix"
print decoder.Q_One_Matrix
print "Decoding"
decoder.decode()
print "Q_One"
print decoder.Q_One
print "sybdrome"
print syndrome
print "estimate"
print decoder.estimate
print "temp_syndrome"
print decoder.temp_syndrome
