from sys import exit

def flip_bit(i, sequence):
    if sequence[i] == 1:
        sequence[i] = -1
    else:
        sequence[i] = 1

class V_node:
    def __init__(self, value = 0):
        self.sockets = []
        self.in_messages = []
        self.out_messages = []
        self.rx_value = value
        self.decoded_value = value
        self.common_message = 0

    def assert_common_message(self, socket):
        self.common_message = self.in_messages[0]
        match = True
        index_set = range(1, len(self.in_messages))
        for i in index_set:
            if self.in_messages[i] != self.common_message:
                    match = False
        return match

    def compute_messages(self):
        for i in range(len(self.out_messages)):
            if self.assert_common_message(i):
                self.out_messages[i] = self.common_message
                self.decoded_value = self.common_message
            else:
                self.decoded_value = self.rx_value
                self.out_messages[i] = self.rx_value

    def pass_message(self, F_nodes):
        i = 0
        for item in self.sockets:
            F_nodes[item[0]].in_messages[item[1]] = self.out_messages[i]
            i += 1

class F_node:
    def __init__(self):
        self.sockets = []
        self.in_messages = []
        self.out_messages = []

    def compute_socket(self, socket):
        index_set = range(len(self.in_messages))
        index_set.remove(socket)
        product = 1
        for i in index_set:
            product = product*self.in_messages[i]
        self.out_messages[socket] = product

    def compute_messages(self):
        for i in range(len(self.out_messages)):
            self.compute_socket(i)

    def pass_message(self, V_nodes):
        i = 0
        for item in self.sockets:
            V_nodes[item[0]].in_messages[item[1]] = self.out_messages[i]
            i += 1
