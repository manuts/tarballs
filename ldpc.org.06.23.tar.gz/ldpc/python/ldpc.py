from ff import GF256int
from polynomial import Polynomial
import numpy

def swap_columns(i, j, M):
    n = M.shape[1]
    I = numpy.zeros(shape=(n, n))
    for k in range(n):
        I[k, k] = 1
    I[i, i] = 0
    I[j, j] = 0
    I[i, j] = 1
    I[j, i] = 1
    return M*I

def swap_index(i, j, index):
    temp = index[0, i]
    index[0, i] = index[0, j]
    index[0, j] = temp
    return index
def add_rows(i, j, M):
    n = M.shape[0]
    I = numpy.zeros(shape=(n, n))
    for k in range(n):
        I[k, k] = 1
    I[j, i] = 1
    return I*M

def regular_check(H, rho, gamma):
    right_regular = True
    left_regular = True
    for i in range(H.shape[0]):
        weight = 0
        for j in range(H.shape[1]):
            weight += H[i, j]
        if weight != rho:
            right_regular = False
    for j in range(H.shape[1]):
        weight = 0
        for i in range(H.shape[0]):
            weight += H[i, j]
        if weight != gamma:
            left_regular = False
    return left_regular, right_regular

def generate_H(rho, gamma):
    q = 256
    g = Polynomial((GF256int(1),))
    for alpha in range(1,rho - 1):
        p = Polynomial((GF256int(1), GF256int(3)**alpha))
        g = g * p
    r0 = g.coefficients[::-1]
    ra = r0 + (GF256int(0),)
    rb = (GF256int(0),) + r0
    r = []
    for i in range(gamma):
        r.append(())
    
    for i in range(len(ra)):
        for j in range(len(r)):
            r[j] = r[j] + (ra[i] + rb[i]*GF256int(1+j),)
    
    H = numpy.zeros(shape=(gamma*q, q*rho))
    
    for i in range(256):
        for j in range(rho):
            H[i, q*j + int(r[0][j]*GF256int(i))] = 1
            for k in range(1, gamma):
                H[i+k*256, q*j + int(r[k][j] +(r[0][j]*GF256int(i)))] = 1
    return H

def convert_binary(H):
    n = H.shape[1]
    m = H.shape[0]
    for i in range(m):
        for j in range(n):
            H[i, j] = H[i, j]%2
    return H

def triangulate_H(H):       # TODO There are errors in this routine
    n = H.shape[1]
    m = H.shape[0]
    index = numpy.zeros(shape=(1, n))
    for i in range(n):
        index[0, i] = i
    for i in range(m):
        j = i
        while j < n:
            if H[i, j] == 1:
                print "swapping column ",
                print i, j
                H = swap_columns(i, j, H)
                index = swap_index(i, j, index)
                print H
                print index
                break
            j += 1
        for k in range(i+1, m):
            if H[k, i] == 1:
                print "adding ",
                print i, k
                H = add_rows(i, k, H)
                print H
        H = convert_binary(H)
        print H
    return index, H
