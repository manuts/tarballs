import numpy
class alist:

    def __init__(self, alist_file = None):
        if ( alist_file != None ):
            self.read(alist_file)
        
    def read(self, alist_file):
        f = open(alist_file)
        line = f.readline()
        wordlist = line.split()
        self.nvar = int(wordlist[0])
        self.ncheck = int(wordlist[1])
        self.mlist = []
        self.nlist = []
        for i in range(self.ncheck):
            self.mlist.append([])
        for i in range(self.nvar):
            self.nlist.append([])
        self.num_mlist = numpy.zeros(self.ncheck, dtype=int)
        self.num_nlist = numpy.zeros(self.nvar, dtype=int)
        line = f.readline()
        wordlist = line.split()
        self.max_num_n = int(wordlist[0])
        self.max_num_m = int(wordlist[1])
        wordlist = (f.readline()).split()
        for i in range(len(wordlist)):
            self.num_nlist[i] = int(wordlist[i])
        wordlist = (f.readline()).split()
        for i in range(len(wordlist)):
            self.num_mlist[i] = int(wordlist[i])
        for i in range(self.nvar):
            wordlist = (f.readline()).split()
            for j in range(len(wordlist)):
                self.nlist[i].append(int(wordlist[j]))
        for i in range(self.ncheck):
            wordlist = (f.readline()).split()
            for j in range(len(wordlist)):
                self.mlist[i].append(int(wordlist[j]))
