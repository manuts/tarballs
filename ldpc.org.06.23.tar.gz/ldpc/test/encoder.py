#!/usr/bin/env python
# 
# Copyright 2013 IIT Bombay.
# Author: Manu T S
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

import numpy as np
from gnuradio import gr
from sys import getsizeof
class ldpc_encoder(gr.sync_block):

    def __init__(self, LDPC_Parity):
        self.matob = LDPC_Parity.matob
        self.matob.make_gen()
        self.N = self.matob.nvar
        self.K = self.N - self.matob.rank
        gr.sync_block.__init__(self, name="ldpc_encoder",
                in_sig = [np.int32]*self.K,
                out_sig = [np.int32]*self.N)


    def work(self, input_items, output_items):
        dataword = np.zeros((self.K, 1), dtype = int)
        for i in range(len(input_items)):
            dataword[i, 0] = input_items[i]
        codeword = self.matob.back_substitution(dataword)
        for i in range(len(output_items)):
            output_items[i][:] = codeword[i, 0]
        return len(output_items[0])
