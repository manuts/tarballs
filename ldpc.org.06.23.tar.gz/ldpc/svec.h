#ifndef SVEC_H
#define SVEC_H
#include <vector>

class sparse_bin_vector
{
    public:
    sparse_bin_vector() {v_size = 0;}
    //! A constructor that initiates an empty sparse vector
    // Parameter sz Size of the sparse vector
    sparse_bin_vector(int sz);
    //! Resize the vector, the vector will be cleared
    void resize(int sz);
    //! Get the size of the vector
    int size() { return v_size; }
    //! Display some information about the vector
    void display_info();
    //! Set elem'th element with val
    void set_element(int elem, int val);
    //! Returns the vector
    std::vector<int> get_vect();

    private:
    int v_size;             // size of vector
    std::vector<int> data;    // Vector contaning non zero elements
    std::vector<int> index; // Indices corresponding to data
};
#endif
