#include <iostream>
#include <stdlib.h>
#include "svec.h"

std::vector<int> sparse_bin_vector::get_vect() {
    std::vector<int> vect(v_size, 0);
    for (int i = 0; i < index.size(); i++) {
        vect[index[i]] = data[i];
    }
    return vect;
}

void sparse_bin_vector::resize(int sz) {
    v_size = sz;
    data.clear();
    index.clear();
}

void sparse_bin_vector::display_info() {
    std::cout << "Length of data is " << data.size() << std::endl;
    std::cout << "Length of index is " << index.size() << std::endl;
    std::cout << "Length of the vector is " << this->size();
    std::cout << std::endl;
    for (int i = 0; i < data.size(); i++) {
        std::cout << data[i] << '\t' << index[i] << std::endl;
    }
}

void sparse_bin_vector::set_element(int elem, int val) {
    if (!((val == 0) || (val == 1))) {
        exit(1);
    }
    else {
        bool found = false;
        int p;
        for ( p = 0; p < index.size(); p++ ) {
            if ( index[p] == elem ) {
                found = true;
                std::cout << "Found" << std::endl;
                break;
            }
        }
        if (found) {
            data[p] = val;
        }
        else {
            data.push_back(val);
            index.push_back(elem);
        }
    }
}

sparse_bin_vector::sparse_bin_vector(int sz) {
    resize(sz);
}
