ldpc
====


==============================================================================
References
==============================================================================
[1] A Class of Low-Density Parity-Check Codes Constructed Based on Reed-Solomon Codes With Two Information Symbols, Ivana Djurdjevic, Jun Xu, Khaled Abdel-Ghaffer and Shu Lin, IEEE Communications Letters, July 2003.

[2] Modern Coding Theory, Tom Richardson and Rudiger Urbanke, Cambridge, 2008
