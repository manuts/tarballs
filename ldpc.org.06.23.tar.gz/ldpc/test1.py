from gf2mat import *
import numpy as np
H = [1,1,0,1,
     0,1,1,1,
     1,0,1,0]
'''     1,1,0,1,
     0,0,1,0]'''
H = np.asarray(H)
X = H.reshape(3, 4)
matob = GF2mat(array_object = X)
matob.row_reduction()
print matob.Hrr.H
print matob.H
print matob.rank()
