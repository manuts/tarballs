#ifndef GF2MAT_H
#define GF2MAT_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <stdlib.h>
#include "smat.h"

class GF2mat_sparse_alist
{
    public:
    //! Default constructor
    GF2mat_sparse_alist() : data_ok(false) {}
    //! Constructor, which reads alist data from a file named fname
    GF2mat_sparse_alist(const std::string &fname);
    //! Read alist data from a file named fname
    void read(const std::string &fname);
    //! Write alist data to a file named fname
    void write(const std::string &fname) const;
    //! Displays some information about the alist object
    virtual void display_info();
    //! Convert "alist" representation to sparse_matrix
    sparse_bin_matrix to_sparse() const;

    //! Return number of columns N
    int get_N();
    //! Return number of rows M
    int get_M();
    //! Return maximum weight of colunms
    int get_max_column_weight();
    //! Return maximum weight of rows
    int get_max_row_weight();
    //! Prints indices with non-zero entry in ith row
    void print_indices_in_row_i(int row);
    //! Prints indices with non-zero entry in ith column
    void print_indices_in_column_i(int column);

    protected:
    //! Flag indicating that "alist" matrix data are properly set
    bool data_ok;
    //! Size of the matrix: M rows x N columns
    int N, M;
    //! Maximum weight of rows
    int max_row_weight;
    //! Maximum weight of columns
    int max_column_weight;
    //! Weight of each column n
    std::vector<int> column_weight;
    //! Weight of each column m
    std::vector<int> row_weight;
    //! List of integer coordinates in the ith row with 
    // non zero entries
    std::vector< std::vector<int> > indices_in_row_i;
    //! List of integer coordinates in the ith column with 
    // non zero entries
    std::vector< std::vector<int> > indices_in_column_i;
};

#endif
