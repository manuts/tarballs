#include <iostream>
#include "smat.h"
#include "gf2mat.h"
#include "ldpc.h"
using namespace std;

int main () {
    // -------------------------------------------------------------
    // Test sparse_bin_vector begins
    /*sparse_bin_vector vect1;
    vect1.display_info();
    sparse_bin_vector vect2(200);
    vect2.set_element(10, 1);
    vect2.display_info();
    vect2.set_element(12, 1);
    vect2.display_info();
    vect2.set_element(15, 1);
    vect2.display_info();
    vector<int> output(200);
    output = vect2.get_vect();
    cout << output.size() << endl;
    int i;
    for ( i = 0; i < output.size() - 1; i++ ) {
        cout << output[i] << ", ";
    }
    cout << output[i] << endl;*/
    // Test sparse_bin_vector ends
    // -------------------------------------------------------------
    // Test sparse_bin_matrix begins
    /*sparse_bin_matrix mat1(4, 8);
    mat1.display_info();
    mat1.set_element(3, 1, 1);
    vector<int> output;
    output = mat1.get_column(3);
    int i;
    for ( i = 0; i < output.size() - 1; i++ ) {
        cout << output[i] << ", ";
    }
    cout << output[i] << endl;*/
    // Test sparse_bin_matrix ends
    // -------------------------------------------------------------
    // Test gf2mat class begins
    /*GF2mat_sparse_alist alist("./alist-files/96.3.963");
    sparse_bin_matrix mat1 = alist.to_sparse();
    vector<int> output;
    output = mat1.get_column(3);
    int i;
    for ( i = 0; i < output.size() - 1; i++ ) {
        cout << output[i] << ", ";
    }
    cout << output[i] << endl;*/
    // Test gf2mat class ends
    // -------------------------------------------------------------
    // Test ldpc class begins
    string fname = "alist-files/96.3.963";
    LDPC_Parity Mat(fname);
    cout << Mat.get_rate();
    return 0;
}
