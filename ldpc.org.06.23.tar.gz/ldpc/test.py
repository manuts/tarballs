from ldpc import *
from gf2mat import *
from numpy import *
from hamming import *
import copy

def bsc(codeword, epsilon):
    err_vect = numpy.zeros(codeword.shape, dtype = int)
    nerr = 0
    for i in range(len(codeword)):
        x = random.uniform(0, 1)
        if x < epsilon:
            if codeword[i] == 0:
                codeword[i] = 1
            else:
                codeword[i] = 0
            err_vect[i] = 1
            nerr += 1
    return nerr, err_vect

#alist_object = GF2mat_sparse_alist(alist_file = "alist-files/96.3.963")
alist_object = GF2mat_sparse_alist(alist_file = "alist-files/4986.93xb.329")
ldpc = LDPC_Parity(alist = alist_object)
encoder = ldpc_encoder(LDPC_Parity = ldpc)
print "maing encoder"
encoder.matob.make_gen()
dataword = random.randint(0, 2, 
        (encoder.matob.nvar - encoder.matob.rank, 1))
print "constructing codeword"
codeword = encoder.matob.back_substitution(dataword)
org_codeword = copy.copy(codeword)
print "Tx through BSC"
(nerr, err_vect) = bsc(codeword, 0.03)
decoder = bp_decoder(LDPC_Parity = ldpc, epsilon = 0.1)
print "Decoder construction"
decoder.Gallager_A(codeword)
print "Decoding"
(stable, success, decoded) = decoder.Gallager_A_decode()
print stable
print success
print array_equal(org_codeword, decoded)
print nerr
