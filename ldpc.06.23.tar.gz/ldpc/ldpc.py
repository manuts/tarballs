from gf2mat import GF2mat

class LDPC_Parity:

    def __init__(self, ncheck = 0, nvar = 0, alist = None):
        if ( alist != None ):
            self.load_alist(alist)
        else:
            self.ncheck = int(ncheck)
            self.nvar = int(nvar)

    def load_alist(self, alist):
        self.alist = alist
        self.nvar = alist.nvar
        self.nchk = alist.ncheck
        self.matob = GF2mat(alist = self.alist)
        self.col_weight = self.alist.num_nlist
        self.row_weight = self.alist.num_mlist
