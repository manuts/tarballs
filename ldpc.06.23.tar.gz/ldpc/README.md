ldpc
====

Working LDPC scripts
