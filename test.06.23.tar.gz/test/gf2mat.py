import numpy
import copy
import time
class GF2mat_sparse_alist:

    def __init__(self, alist_file = None):
        if ( alist_file != None ):
            self.read(alist_file)
        
    def read(self, alist_file):
        f = open(alist_file)
        line = f.readline()
        wordlist = line.split()
        self.nvar = int(wordlist[0])
        self.ncheck = int(wordlist[1])
        self.mlist = []
        self.nlist = []
        for i in range(self.ncheck):
            self.mlist.append([])
        for i in range(self.nvar):
            self.nlist.append([])
        self.num_mlist = numpy.zeros(self.ncheck, dtype=int)
        self.num_nlist = numpy.zeros(self.nvar, dtype=int)
        line = f.readline()
        wordlist = line.split()
        self.max_num_n = int(wordlist[0])
        self.max_num_m = int(wordlist[1])
        wordlist = (f.readline()).split()
        for i in range(len(wordlist)):
            self.num_nlist[i] = int(wordlist[i])
        wordlist = (f.readline()).split()
        for i in range(len(wordlist)):
            self.num_mlist[i] = int(wordlist[i])
        for i in range(self.nvar):
            wordlist = (f.readline()).split()
            for j in range(len(wordlist)):
                self.nlist[i].append(int(wordlist[j]))
        for i in range(self.ncheck):
            wordlist = (f.readline()).split()
            for j in range(len(wordlist)):
                self.mlist[i].append(int(wordlist[j]))

class GF2mat:
    def __init__(self, nvar = 0, ncheck = 0, alist = None, array_object = None):
        if ((alist == None) and (array_object == None)):
            self.nvar = nvar
            self.ncheck = ncheck
            self.H = numpy.zeros((self.ncheck, self.nvar), dtype = int)
        elif (array_object == None):
            self.ncheck = alist.ncheck
            self.nvar = alist.nvar
            self.H = numpy.zeros((self.ncheck, self.nvar), dtype = int)
            for i in range(len(alist.mlist)):
                for j in range(len(alist.mlist[i])):
                    self.H[i, alist.mlist[i][j] - 1] = 1
        else:
            self.ncheck = array_object.shape[0]
            self.nvar = array_object.shape[1]
            self.H = numpy.zeros((self.ncheck, self.nvar), dtype = int)
            for i in range(self.ncheck):
                for j in range(self.nvar):
                    self.H[i, j] = array_object[i, j]

    def copy_H(self):
        self.H_copy = copy.copy(self.H)

    def get(self, i, j):
        return self.H[i, j]

    def set(self, i, j):
        self.H[i, j] = 1

    def clear(self, i, j):
        self.H[i, j] = 0

    def get_row(self, i):
        row = numpy.zeros(self.nvar, dtype = int)
        for j in range(self.nvar):
            row[j] = self.H[i, j]
        return row

    def set_row(self, i, vect):
        for j in range(self.nvar):
            self.H[i, j] = vect[j]

    def get_col(self, i):
        col = numpy.zeros((self.ncheck, 1), dtype = int)
        for j in range(self.ncheck):
            col[j, 0] = self.H[j, i]
        return col

    def set_col(self, i, vect):
        for j in range(self.ncheck):
            self.H[j, i] = vect[j, 0]

    def swap_rows(self, i, j):
        temp = self.get_row(i)
        self.set_row(i, self.get_row(j))
        self.set_row(j, temp)

    def swap_cols(self, i, j):
        temp = self.get_col(i)
        self.set_col(i, self.get_col(j))
        self.set_col(j, temp)

    def add_rows(self, i, j):
        for k in range(self.nvar):
            self.H[i, k] = (self.H[i, k] + self.H[j, k])%2

    def add_cols(self, i, j):
        for k in range(self.ncheck):
            self.H[k, i] = (self.H[k, i] + self.H[k, j])%2

    def transpose_H(self):
        Ht = GF2mat(nvar = self.ncheck, ncheck = self.nvar)
        for i in range(self.ncheck):
            row = self.get_row(i)
            Ht.set_col(i, row.reshape(self.nvar, 1))
        return Ht

    def T_fact(self):           # FIXME
        self.copy_H()
        self.T = gf2mat_I(self.ncheck)
        self.U = self
        self.perm = numpy.zeros(self.nvar, dtype = int)
        for i in range(self.nvar):
            self.perm[i] = i
        for j in range(self.ncheck):
            found = False
            for i1 in range(j, self.ncheck):
                for j1 in range(j, self.nvar):
                    if (self.U.get(i1, j1) == 1):
                        found = True
                        break
                if found:
                    break
            if (found == False):
                self.H = self.H_copy
                return j
            else:
                self.U.swap_rows(i1, j)
                self.T.swap_rows(i1, j)
                self.U.swap_cols(j1, j)
                temp = self.perm[j]
                self.perm[j] = self.perm[j1]
                self.perm[j1] = temp
                for i1 in range(j + 1, self.ncheck):
                    if (self.U.get(i1, j) == 1):
                        self.U.add_rows(i1, j)
                        self.T.add_rows(i1, j)
            self.H = self.H_copy
            return self.ncheck

    def row_reduction(self):
        self.Hrr = GF2mat(array_object = self.H)
        for i in range(min(self.nvar, self.ncheck)):
            for j in range(i, self.ncheck):
                if (self.Hrr.H[j, i] == 1):
                    self.Hrr.swap_rows(j, i)
                    break
            for k in range(j + 1, self.ncheck):
                if (self.Hrr.H[k, i] == 1):
                    self.Hrr.add_rows(k, i)

    def rank(self):
        for i in range(self.ncheck):
            non_zero = False
            for j in range(self.nvar):
                if self.Hrr.get(i, j) == 1:
                    non_zero = True
            if non_zero == False:
                break
        return i

    def make_gen(self):
        self.G = GF2mat(array_object = self.H)
        self.permute = numpy.zeros(self.nvar, dtype = int)
        for col in range(self.nvar):
            self.permute[col] = col
        self.rank = 0
        diag = 0
        limit = self.ncheck
        while diag < limit:
            non_zero = False
            for col in range(diag, self.nvar):
                if self.G.get(diag, col) == 1:
                    non_zero = True
                    self.rank += 1
                    self.G.swap_cols(diag, col)
                    temp = self.permute[diag]
                    self.permute[diag] = self.permute[col]
                    self.permute[col] = temp
                    break
            if non_zero:
                for row in range(diag + 1, self.ncheck):
                    if (self.G.get(row, diag) == 1):
                        self.G.add_rows(row, diag)
                diag += 1
            else:
                current_row = self.G.get_row(diag)
                for row in range(diag, limit - 1):
                    self.G.set_row(row, self.G.get_row(row + 1))
                self.G.set_row(limit - 1, current_row)
                limit -= 1
            print diag, limit

    def back_substitution(self, dataword):
        if (len(dataword) == self.nvar - self.rank):
            codeword = numpy.zeros((self.nvar, 1), dtype = int)
            for i in range(self.rank, self.nvar):
                codeword[i, 0] = dataword[i - self.rank, 0]
            for i in range(self.rank - 1, -1, -1):
                 codeword[i] = numpy.dot(self.G.get_row(i)[i + 1:], codeword[i + 1:])%2
            permuted_codeword = numpy.zeros((self.nvar, 1), dtype = int)
            for i in range(self.nvar):
                permuted_codeword[self.permute[i], 0] = codeword[i]
            return permuted_codeword
        else:
            return "can't encode" # FIXME
                
def gf2mat_I(m):
    z = GF2mat(nvar = m, ncheck = m)
    for i in range(m):
        z.set(i, i)
    return z
