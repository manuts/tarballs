from sys import exit

class V_node:
    def __init__(self, value = 0):
        self.sockets = []
        self.in_messages = []
        self.out_messages = []
        self.rx_value = value
        self.decoded_value = value
        self.common_message = 0

    def assert_common_message(self, socket):
        self.common_message = 0
        match = True
        index_set = range(len(self.in_messages))
#        index_set.remove(socket)
        for i in index_set:
            if self.in_messages[i] != 0:
                if self.common_message == 0:
                    self.common_message = self.in_messages[i]
                elif self.common_message != self.in_messages[i]:
                    match = False
        if self.rx_value != 0:
            if self.common_message == 0:
                self.common_message = self.rx_value
            elif self.common_message != self.rx_value:
                match = False
        return match

    def compute_messages(self):
        for i in range(len(self.out_messages)):
            if self.assert_common_message(i):
                self.out_messages[i] = self.common_message
                self.decoded_value = self.common_message
            else:
                exit("Common message doesn't match. Exiting")

    def pass_message(self, F_nodes):
        i = 0
        for item in self.sockets:
            F_nodes[item[0]].in_messages[item[1]] = self.out_messages[i]
            i += 1

class F_node:
    def __init__(self):
        self.sockets = []
        self.in_messages = []
        self.out_messages = []

    def compute_socket(self, socket):
        index_set = range(len(self.in_messages))
        index_set.remove(socket)
        n_erasure = 0
        product = 1
        for i in index_set:
            if self.in_messages[i] == 0:
                n_erasure += 1
            else:
                product = product*self.in_messages[i]
        if n_erasure == 0:
            self.out_messages[socket] = product
        else:
            self.out_messages[socket] = 0

    def compute_messages(self):
        for i in range(len(self.out_messages)):
            self.compute_socket(i)

    def pass_message(self, V_nodes):
        i = 0
        for item in self.sockets:
            V_nodes[item[0]].in_messages[item[1]] = self.out_messages[i]
            i += 1
