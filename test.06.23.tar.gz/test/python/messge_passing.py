from numpy import *
from nodes import *
from ldpc import generate_H

#+++++++++++++++++++++++++++++++++++++++++++
# G is the generator matrix
# H is the parity check matrix
#G = mat("1 1 0 1 0 0 0; 0 1 1 0 1 0 0; 1 1 1 0 0 1 0; 1 0 1 0 0 0 1")
#H = mat("1 0 0 1 0 1 1; 0 1 0 1 1 1 0; 0 0 1 0 1 1 1")
H = generate_H(32, 6)

n_function_node = shape(H)[0]
n_variable_node = shape(H)[1]

#codeword = random.randint(0, 1, n_variable_node)
#print "Random generated data"
#print data
#-------------------------------------------

#+++++++++++++++++++++++++++++++++++++++++++
# Encoding
#codeword = data*G
codeword = random.randint(-1, 0, n_variable_node)
#print codeword
# Make it into binary field
#for i in range(7):
#    codeword[0, i] = codeword[0, i]%2
#bin_codeword = codeword
#print "Codeword at the output of encoder"
#print codeword
#-------------------------------------------

#+++++++++++++++++++++++++++++++++++++++++++
# Mapping 0 to 1 and 1 to -1
#for i in range(n_variable_node):
#    if codeword[0, i] == 0:
#        codeword[0, i] = 1
#    else:
#        codeword[0, i] = -1
#print "Channel input"
#print codeword
#-------------------------------------------

#+++++++++++++++++++++++++++++++++++++++++++
# Channel introducing errors
# 0 in the channel output indicates erasures
# epsilon is the erasure probability
epsilon = 0.1
channel = random.uniform(0.0, 1.0, (1, n_variable_node))
n_erasures = 0
for i in range(n_variable_node):
    if channel[0, i] < epsilon:
        codeword[i] = 0
        n_erasures += 1

# Use the following to test with specific channel output
#    codeword[0, 0] = 0
#    codeword[0, 1] = 0
#    codeword[0, 2] = 1
#    codeword[0, 3] = 0
#    codeword[0, 4] = 1
#    codeword[0, 5] = 1
#    codeword[0, 6] = 1

#print "channel output"
#print codeword
print "number of erasures introduced is ",
print n_erasures
#-------------------------------------------

#+++++++++++++++++++++++++++++++++++++++++++
# Initializing the tanner graph
F_nodes = [] 
for i in range(n_function_node):
    node = F_node()
    F_nodes.append(node)

V_nodes = []
for i in range(n_variable_node):
    node = V_node(codeword[i])
    V_nodes.append(node)

# socekts defines the list of sockets with the following order
# [n, k]
# k'th socket connecting to n'th node on the other side of the bipartite graph
for i in range(n_function_node):
    for j in range(n_variable_node):
        if H[i, j] == 1:
            v_free = len(V_nodes[j].sockets)
            f_free = len(F_nodes[i].sockets)
            F_nodes[i].sockets.append([j, v_free])
            F_nodes[i].in_messages.append(0)
            F_nodes[i].out_messages.append(0)
            V_nodes[j].sockets.append([i, f_free])
            V_nodes[j].in_messages.append(0)
            V_nodes[j].out_messages.append(0)
##-------------------------------------------
#
##+++++++++++++++++++++++++++++++++++++++++++
# Message passing decoding
# Specify n_iterations
n_iterations = 10

for k in range(n_iterations):
    for i in range(n_function_node):
        F_nodes[i].pass_message(V_nodes)
    
    for i in range(n_variable_node):
        V_nodes[i].compute_messages()
    
#///////////////////////////////////////////
# Uncomment the following to see decoded value in each iterations
#    print "decoded value"
#    for i in range(n_variable_node):
#        print V_nodes[i].decoded_value,
#    print
#///////////////////////////////////////////
    
    for i in range(n_variable_node):
        V_nodes[i].pass_message(F_nodes)
    
    for i in range(n_function_node):
        F_nodes[i].compute_messages()
#-------------------------------------------

#+++++++++++++++++++++++++++++++++++++++++++
# Mapping back to binary field
decoded = zeros((1, n_variable_node), dtype="int")
for i in range(n_variable_node):
    if V_nodes[i].decoded_value == -1:
        decoded[0, i] = 1
    elif V_nodes[i].decoded_value == 1:
        decoded[0, i] = 0
    else:
        decoded[0, i] = 2
n = 0
for i in range(n_variable_node):
    if decoded[0, i] == 2:
        n += 1
print "erasures after correction is ",
print n
#print "Decoded codeword"
##print decoded
##-------------------------------------------
#
##+++++++++++++++++++++++++++++++++++++++++++
## Checking if deciding is success
##if decoded.all() == bin_codeword.all():
##    print "Success"
##else:
##    print "Failure"
##-------------------------------------------
