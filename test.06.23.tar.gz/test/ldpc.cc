#include "ldpc.h"

LDPC_Parity::LDPC_Parity(int nc, int nv) : init_flag(false) {
    initialize(nc, nv);
}

void LDPC_Parity::initialize(int nc, int nv) {
    ncheck = nc;
    nvar = nv;
    init_flag = true;
}

void LDPC_Parity::display_stats() const {
    std::cout << "Number of variable nodes is " << nvar;
    std::cout << std::endl;
    std::cout << "Number of check nodes is " << ncheck;
    std::cout << std::endl;
}

void LDPC_Parity::import_alist(const GF2mat_sparse_alist& alist)
{
  H = alist.to_sparse();
  initialize(H.get_M(), H.get_N());
}

LDPC_Parity::LDPC_Parity(const std::string& filename) 
        : init_flag(false)
{
    import_alist(GF2mat_sparse_alist(filename));
}
