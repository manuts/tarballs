import numpy as np
from gnuradio import gr

class mock_encoder(gr.sync_block):

    def __init__(self):
        gr.sync_block.__init__(self, name="mock_encoder",
                in_sig = [np.int32]*4,
                out_sig = [np.int32]*5)

    def work(self, input_items, output_items):
        for i in range(len(input_items)):
            output_items[i][:] = 2*input_items[i]
        i += 1
        output_items[i][:] = 8
        return len(output_items[0])
        
