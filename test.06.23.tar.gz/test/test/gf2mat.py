import numpy
import copy

class GF2mat:
    def __init__(self, nvar = 0, ncheck = 0,
            alist = None, array_object = None):
        if ((alist == None) and (array_object == None)):
            self.nvar = nvar
            self.ncheck = ncheck
            self.H = numpy.zeros((self.ncheck, self.nvar),
                    dtype = int)
        elif (array_object == None):
            self.ncheck = alist.ncheck
            self.nvar = alist.nvar
            self.H = numpy.zeros((self.ncheck, self.nvar),
                    dtype = int)
            for i in range(len(alist.mlist)):
                for j in range(len(alist.mlist[i])):
                    self.H[i, alist.mlist[i][j] - 1] = 1
        else:
            self.ncheck = array_object.shape[0]
            self.nvar = array_object.shape[1]
            self.H = numpy.zeros((self.ncheck, self.nvar),
                    dtype = int)
            for i in range(self.ncheck):
                for j in range(self.nvar):
                    self.H[i, j] = array_object[i, j]

    def copy_H(self):
        self.H_copy = copy.copy(self.H)

    def get(self, i, j):
        return self.H[i, j]

    def set(self, i, j):
        self.H[i, j] = 1

    def clear(self, i, j):
        self.H[i, j] = 0

    def get_row(self, i):
        row = numpy.zeros(self.nvar, dtype = int)
        for j in range(self.nvar):
            row[j] = self.H[i, j]
        return row

    def set_row(self, i, vect):
        for j in range(self.nvar):
            self.H[i, j] = vect[j]

    def get_col(self, i):
        col = numpy.zeros((self.ncheck, 1), dtype = int)
        for j in range(self.ncheck):
            col[j, 0] = self.H[j, i]
        return col

    def set_col(self, i, vect):
        for j in range(self.ncheck):
            self.H[j, i] = vect[j, 0]

    def swap_rows(self, i, j):
        temp = self.get_row(i)
        self.set_row(i, self.get_row(j))
        self.set_row(j, temp)

    def swap_cols(self, i, j):
        temp = self.get_col(i)
        self.set_col(i, self.get_col(j))
        self.set_col(j, temp)

    def add_rows(self, i, j):
        for k in range(self.nvar):
            self.H[i, k] = (self.H[i, k] + self.H[j, k])%2

    def add_cols(self, i, j):
        for k in range(self.ncheck):
            self.H[k, i] = (self.H[k, i] + self.H[k, j])%2

    def transpose_H(self):
        Ht = GF2mat(nvar = self.ncheck, ncheck = self.nvar)
        for i in range(self.ncheck):
            row = self.get_row(i)
            Ht.set_col(i, row.reshape(self.nvar, 1))
        return Ht

    def make_gen(self):
        self.G = GF2mat(array_object = self.H)
        self.permute = numpy.zeros(self.nvar, dtype = int)
        for col in range(self.nvar):
            self.permute[col] = col
        self.rank = 0
        diag = 0
        limit = self.ncheck
        while diag < limit:
            non_zero = False
            for col in range(diag, self.nvar):
                if self.G.get(diag, col) == 1:
                    non_zero = True
                    self.rank += 1
                    self.G.swap_cols(diag, col)
                    temp = self.permute[diag]
                    self.permute[diag] = self.permute[col]
                    self.permute[col] = temp
                    break
            if non_zero:
                for row in range(diag + 1, self.ncheck):
                    if (self.G.get(row, diag) == 1):
                        self.G.add_rows(row, diag)
                diag += 1
            else:
                current_row = self.G.get_row(diag)
                for row in range(diag, limit - 1):
                    self.G.set_row(row, self.G.get_row(row + 1))
                self.G.set_row(limit - 1, current_row)
                limit -= 1
#            print diag, limit

    def back_substitution(self, dataword):
        if (len(dataword) == self.nvar - self.rank):
            codeword = numpy.zeros((self.nvar, 1), dtype = int)
            for i in range(self.rank, self.nvar):
                codeword[i, 0] = dataword[i - self.rank, 0]
            for i in range(self.rank - 1, -1, -1):
                 codeword[i] = numpy.dot(self.G.get_row(i)[i + 1:], codeword[i + 1:])%2
            permuted_codeword = numpy.zeros((self.nvar, 1), dtype = int)
            for i in range(self.nvar):
                permuted_codeword[self.permute[i], 0] = codeword[i]
            return permuted_codeword
        else:
            return "can't encode" # FIXME
