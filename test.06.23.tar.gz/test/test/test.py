#!/usr/bin/env python
# 
# Copyright 2013 IIT Bombay.
# Author: Manu T S
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 
"""
from gnuradio import gr, blocks
from mock_encoder import mock_encoder
import numpy as np

class my_tb(gr.top_block):
    def __init__(self):
        gr.top_block.__init__(self)
#        dataword = np.zeros(10, dtype = int)
#        self.datatpl = tuple(dataword)
        self.datatpl = (1, 0, 1, 0)
        self.src = blocks.vector_source_i(self.datatpl)
        str2vec = blocks.stream_to_streams(4, 4)
        self.coder = mock_encoder()
        vec2str = blocks.streams_to_stream(4, 5)
        self.dst = blocks.vector_sink_i()
#        self.connect(self.src, self.dst)
        self.connect(self.src, str2vec)
        for i in range(4):
            self.connect((str2vec, i), (self.coder, i))
            self.connect((self.coder, i), (vec2str, i))
        i += 1
        self.connect((self.coder, i), (vec2str, i))
        self.connect(vec2str, self.dst)
"""

from gnuradio import gr, blocks
from encoder import ldpc_encoder
from ldpc import LDPC_Parity
from alist import alist
import numpy as np
import random

class my_tb(gr.top_block):
    def __init__(self):
        gr.top_block.__init__(self)

        self.alist = alist(alist_file = "alist-files/96.3.963")
        self.ldpc = LDPC_Parity(alist = self.alist)
        self.coder = ldpc_encoder(self.ldpc)
        K = self.coder.K
        N = self.coder.N
        dataword = np.zeros(K, dtype = int)
        datatpl = ()
        for i in range(K):
            datatpl = datatpl + (random.randint(0, 1),)
        print "mark1"
        print datatpl
        print "mark2"
        self.src = blocks.vector_source_i(datatpl)
        str2vec = blocks.stream_to_streams(4, K)
        vec2str = blocks.streams_to_stream(4, N)
        self.dst = blocks.vector_sink_i()
        self.connect(self.src, str2vec)
        for i in range(K):
            self.connect((str2vec, i), (self.coder, i))
        for i in range(N):
            self.connect((self.coder, i), (vec2str, i))
        self.connect(vec2str, self.dst)

def main():
    tb = my_tb()
    tb.run()
    print tb.dst.data()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass

"""
from ldpc import LDPC_Parity
import numpy as np
from encoder import ldpc_encoder
from decoder import bp_decoder
from alist import alist
import copy
import random

def bsc(codeword, epsilon):
    err_vect = np.zeros(codeword.shape, dtype = int)
    nerr = 0
    for i in range(len(codeword)):
        x = random.uniform(0, 1)
        if x < epsilon:
            if codeword[i] == 0:
                codeword[i] = 1
            else:
                codeword[i] = 0
            err_vect[i] = 1
            nerr += 1
    return nerr, err_vect

alist_object = alist(alist_file = "alist-files/816.55.156")
ldpc = LDPC_Parity(alist = alist_object)
encoder = ldpc_encoder(LDPC_Parity = ldpc)
print "maing encoder"
dataword = [random.randint(0, 1) for x in
        range(encoder.matob.nvar - encoder.matob.rank)]
dataword = np.asarray(dataword)
shape = dataword.shape
print shape
dataword = dataword.reshape(shape[0], 1)
print "constructing codeword"
codeword = encoder.matob.back_substitution(dataword)
org_codeword = copy.copy(codeword)
print "Tx through BSC"
(nerr, err_vect) = bsc(codeword, 0.03)
decoder = bp_decoder(LDPC_Parity = ldpc, epsilon = 0.1)
print "Decoder construction"
decoder.Gallager_A(codeword)
print "Decoding"
(stable, success, decoded) = decoder.Gallager_A_decode()
print stable
print success
print np.array_equal(org_codeword, decoded)
print nerr
"""
