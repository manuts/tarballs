#include "gf2mat.h"
using namespace std;

GF2mat_sparse_alist::GF2mat_sparse_alist(const std::string &fname)
    : data_ok(false) {
    read(fname);
}

void GF2mat_sparse_alist::read(const std::string &fname) {
    std::ifstream file;
    std::string line;
    std::stringstream ss;
    
    file.open(fname.c_str());
    if(!(file.is_open())) {
        std::cout << "Could not open the file" << std::endl;
    }

    // Parse N and M
    std::getline(file, line);
    ss << line;
    ss >> N >> M;
    column_weight.resize(N);
    row_weight.resize(M);
    indices_in_column_i.resize(N);
    indices_in_row_i.resize(M);
    ss.seekg(0, std::ios::end);
    ss.clear();

    // parse max_num_n and max_num_m
    std::getline(file, line);
    ss << line;
    ss >> max_column_weight >> max_row_weight;
    ss.seekg(0, std::ios::end);
    ss.clear();

    // Parse weight of each column n
    std::getline(file, line);
    ss << line;
    for (int i = 0; i < N; i++ ) {
        ss >> column_weight[i];
        indices_in_column_i[i].resize(column_weight[i]);
    }
    ss.seekg(0, std::ios::end);
    ss.clear();

    // Parse weight of each row m
    std::getline(file, line);
    ss << line;
    for (int i = 0; i < M; i++ ) { 
        ss >> row_weight[i];
        indices_in_row_i[i].resize(row_weight[i]);
    }
    ss.seekg(0, std::ios::end);
    ss.clear();

    // Parse indices with non zero entries in ith column
    for (int column = 0; column < N; column++) {
        std::getline(file, line);
        ss << line;
        for (int entry = 0; entry < column_weight[column]; entry++) {
            ss >> indices_in_column_i[column][entry];
        }
        ss.seekg(0, std::ios::end);
        ss.clear();
    }

    // Parse indices with non zero entries in ith row
    for (int row = 0; row < N; row++) {
        std::getline(file, line);
        ss << line;
        for (int entry = 0; entry < row_weight[row]; entry++) {
            ss >> indices_in_row_i[row][entry];
        }
        ss.seekg(0, std::ios::end);
        ss.clear();
    }

    file.close();
    data_ok = true;
}

void GF2mat_sparse_alist::write(const string &fname) const
{
    if (!data_ok) {
        cout << "Data not ok, exiting" << endl;
        exit(1);
    }
    // Else
    std::ofstream file(fname.c_str(), std::ofstream::out);
    // Write N and M
    file << N << " " << M << std::endl;
    file << max_column_weight << " " << max_row_weight << std::endl;
    // Write column weights
    for (int i = 0; i < column_weight.size() - 1; i++) {
        file << column_weight[i] << " ";
    }
    file << column_weight[column_weight.size() - 1] << std::endl;
    // Write row weights
    for (int i = 0; i < row_weight.size() - 1; i++) {
        file << row_weight[i] << " ";
    }
    file << row_weight[row_weight.size() - 1] << std::endl;
    // Write non zero indices in the ith column
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < column_weight[i] - 1; j++) {
            file << indices_in_column_i[i][j] << " ";
        }
        file << indices_in_column_i[i][column_weight[i] - 1];
        file << std::endl;
    }
    // Write non zero indices in the ith row
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < row_weight[i] - 1; j++) {
            file << indices_in_row_i[i][j] << " ";
        }
        file << indices_in_row_i[i][row_weight[i] - 1];
        file << std::endl;
    }
    file.close();
}

void GF2mat_sparse_alist::display_info() {
    cout << "Number of rows M " << M << endl;
    cout << "Number of columns N " << N << endl;
    cout << "size of row_weight " << row_weight.size() << endl;
    cout << "size of column_weight " << column_weight.size() << endl;
    cout << "maximum weight of rows max_row_weight "; 
    cout << max_row_weight << endl;
    cout << "maximum weight of columns max_column_weight " ;
    cout << max_column_weight << endl;
    cout << "column_weight printed below" << endl;
    for (int i = 0; i < N-1; i++) {
        cout << column_weight[i] << ", ";
    }
    cout << column_weight[N-1] << endl;
    cout << "row_weight printed below" << endl;
    for (int i = 0; i < M-1; i++) {
        cout << row_weight[i] << ", ";
    }
    cout << row_weight[M-1] << endl;
    cout << "Data ok = " << data_ok << endl;
}

int GF2mat_sparse_alist::get_N() {
    return N;
}

int GF2mat_sparse_alist::get_M() {
    return M;
}

int GF2mat_sparse_alist::get_max_column_weight() {
    return max_column_weight;
}

int GF2mat_sparse_alist::get_max_row_weight() {
    return max_row_weight;
}

void GF2mat_sparse_alist::print_indices_in_column_i(int column) {
    cout << "Indices in column " << column << endl;
    for (int i = 0; i < column_weight[column] - 1; i++) {
        cout << indices_in_column_i[column][i] << ", ";
    }
    cout << indices_in_column_i[column][column_weight[column] - 1] << endl;
}

void GF2mat_sparse_alist::print_indices_in_row_i(int row) {
    cout << "Indices in row " << row << endl;
    for (int i = 0; i < row_weight[row] - 1; i++) {
        cout << indices_in_row_i[row][i] << ", ";
    }
    cout << indices_in_row_i[row][row_weight[row] - 1] << endl;
}

sparse_bin_matrix GF2mat_sparse_alist::to_sparse() const
{
    sparse_bin_matrix smat(M, N);
    for (int column = 0; column < N; column++) {
        for (int j = 0; j < column_weight[column]; j++) {
            smat.set_element(column,
                    indices_in_column_i[column][j]-1, 1);
        }
    }
    return smat;
}
