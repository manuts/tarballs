#ifndef SMAT_H
#define SMAT_H

#include <vector>
#include "svec.h"

class sparse_bin_matrix {
    public:
    //! Default constructor
    sparse_bin_matrix() : M(0), N(0) {}
    //! Constructor
    sparse_bin_matrix(int m, int n);
    //! Display info
    void display_info ();
    //! Set (row, column)th value equal to val
    void set_element(int column, int row, int value);
    //! Print ith column
    std::vector<int> get_column(int column);
    int get_M() { return M; }
    int get_N() { return N; }

    private:
    //! Matrix is an M x N matrix
    int M, N;
    std::vector<sparse_bin_vector> columns;
};
#endif
